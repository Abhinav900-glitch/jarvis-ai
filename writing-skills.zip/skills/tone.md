# Tone

- Match the reader's level of urgency and expertise.
- In technical writing, neutral beats clever.
- Keep personality in examples, not in the instructions.
- Avoid sarcasm in anything the reader may be stressed about.

## Leveling

- Beginner: define terms on first use; avoid stacking jargon.
- Peer: skip the basics, focus on tradeoffs.
- Executive: lead with impact, then cost, then timeline.

