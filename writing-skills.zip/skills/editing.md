# Editing

- Write the rough draft to think; edit for the reader.
- Cut before you polish.
- Replace a fuzzy verb with a precise one where it matters.
- Check for repeated sentence openings.

## Self-checklist

- [ ] Did I answer the question I set out to answer?
- [ ] Is the first sentence of each paragraph doing real work?
- [ ] Are the examples tighter than the abstractions?
- [ ] Would a tired reader still understand this?

