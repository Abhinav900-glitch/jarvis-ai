# Email writing

- Subject line should predict the body, not decorate it.
- First paragraph: why this exists.
- Keep requests in their own sentence or list item.
- Close with the specific next action and owner.

## Short email template

- Subject: decision needed: X
- Context: one line
- Options: A / B / C
- Recommendation: one line
- Asks: who decides, by when

