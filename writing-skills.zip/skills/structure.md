# Structure

- Open with the reader's question, not the author's process.
- Put the most important line first; supporting detail comes after.
- One paragraph, one job. If a paragraph does two things, split it.
- Use subheadings when the reader will scan.

## Common layouts

- **Answer-first**: point, evidence, caveat, next step.
- **Compare**: what differs, why it matters, when each applies.
- **Process**: precondition, steps in order, failure modes, end state.

