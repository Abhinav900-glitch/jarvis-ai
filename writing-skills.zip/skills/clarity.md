# Clarity

- Prefer one idea per sentence.
- State the point before the explanation.
- Cut qualifiers that do not change the meaning ("very", "really", "basically").
- Use concrete nouns over abstract ones when the reader needs to picture something.

## Tightening pass

1. Read aloud.
2. Delete the weakest sentence in each paragraph.
3. Replace "in order to" with "to".
4. Replace "due to the fact that" with "because".

