# Style guide (working notes)

- Prefer active voice unless the actor is unknown or irrelevant.
- Use "we" sparingly; make clear who "we" is.
- Keep lists parallel: all nouns, all verbs, or all full sentences.
- Edge cases belong after the common path, not inside it.
- When two phrasings are both correct, pick the shorter one.

## Consistency rules

- Same term, same meaning, every time.
- One convention for code references, one for UI labels, one for files.
- Dates: spell out the format at first use if it matters.

